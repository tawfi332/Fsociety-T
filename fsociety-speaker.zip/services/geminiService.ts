
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { MentorMessage } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const MENTOR_SYSTEM_INSTRUCTION = `
You are Fsociety-Speaker, a direct and insightful English speaking mentor.
Your goal is to help users master English for business and mindset growth.

For EVERY message the user sends:
1. Identify errors in grammar, vocabulary, or tone.
2. Provide corrections: original, corrected, and a clear "why".
3. Give brief overall feedback on their clarity.
4. Reply as a mentor, focusing on high-level topics like business, strategy, and mindset. Be sharp, efficient, and encouraging.

Format your response strictly as JSON:
{
  "corrections": [
    {
      "original": "text",
      "corrected": "text",
      "explanation": "text"
    }
  ],
  "overallFeedback": "short summary",
  "mentorResponse": "your conversational reply"
}
`;

export const getMentorResponse = async (
  message: string, 
  history: MentorMessage[]
): Promise<any> => {
  const model = 'gemini-3-flash-preview';
  
  const contents = history.map(msg => ({
    role: msg.role === 'user' ? 'user' : 'model',
    parts: [{ text: msg.role === 'assistant' ? JSON.stringify({ mentorResponse: msg.content }) : msg.content }]
  }));

  contents.push({
    role: 'user',
    parts: [{ text: message }]
  });

  const response: GenerateContentResponse = await ai.models.generateContent({
    model,
    contents: contents as any,
    config: {
      systemInstruction: MENTOR_SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          corrections: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                original: { type: Type.STRING },
                corrected: { type: Type.STRING },
                explanation: { type: Type.STRING }
              }
            }
          },
          overallFeedback: { type: Type.STRING },
          mentorResponse: { type: Type.STRING }
        },
        required: ["corrections", "overallFeedback", "mentorResponse"]
      }
    }
  });

  try {
    return JSON.parse(response.text);
  } catch (e) {
    return {
      corrections: [],
      overallFeedback: "I understood your message.",
      mentorResponse: response.text
    };
  }
};
