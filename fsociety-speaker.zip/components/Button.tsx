
// This file is obsolete in the Fsociety-Speaker simple version.
export default () => null;
