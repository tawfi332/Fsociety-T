
import React from 'react';
import { MentorMessage } from '../types';

interface MessageBubbleProps {
  message: MentorMessage;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isAssistant = message.role === 'assistant';

  return (
    <div className={`flex w-full mb-6 flex-col ${isAssistant ? 'items-start' : 'items-end'}`}>
      {/* Sender Label */}
      <div className={`text-[10px] uppercase tracking-widest font-bold mb-1 opacity-50 mono ${isAssistant ? 'ml-1' : 'mr-1'}`}>
        {isAssistant ? 'fsociety_speaker' : 'user_session'}
      </div>

      <div className={`max-w-[90%] md:max-w-[80%]`}>
        {/* Main Bubble */}
        <div className={`rounded-xl p-4 ${
          isAssistant 
            ? 'bg-slate-800 border border-slate-700 text-slate-100 shadow-lg' 
            : 'bg-white text-slate-900 border border-slate-200'
        }`}>
          <p className="text-sm leading-relaxed whitespace-pre-wrap">
            {message.content}
          </p>
        </div>

        {/* Feedback block */}
        {isAssistant && (message.corrections?.length || message.overallFeedback) && (
          <div className="mt-3 space-y-2">
            {message.corrections && message.corrections.length > 0 && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3">
                <div className="text-[9px] font-bold text-red-400 uppercase tracking-tighter mb-2 mono flex items-center gap-1">
                  <i className="fa-solid fa-bug"></i> syntax_errors_detected
                </div>
                <div className="space-y-3">
                  {message.corrections.map((corr, idx) => (
                    <div key={idx} className="text-xs">
                      <div className="flex flex-col gap-0.5">
                        <span className="text-slate-500 line-through text-[11px]">"{corr.original}"</span>
                        <span className="text-emerald-400 font-medium">→ "{corr.corrected}"</span>
                        <p className="text-slate-400 italic text-[10px] mt-0.5">{corr.explanation}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {message.overallFeedback && (
              <div className="text-[10px] text-slate-400 bg-slate-800/50 px-2 py-1 rounded border border-slate-700 mono">
                feedback: {message.overallFeedback}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default MessageBubble;
